using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : EnemyController 
{
    //EnemyController Scriptinden kal�t�m al�yoruz.
}
