//IDamageable interface'i
public interface IDamageable
{
    void TakeDamage(int damageValue);
}
