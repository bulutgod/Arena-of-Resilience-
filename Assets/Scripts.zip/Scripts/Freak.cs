using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Freak : EnemyController
{
    //EnemyController Scriptinden kal�t�m al�yoruz.
}
